Sound pack downloaded from Freesound
----------------------------------------

"Piano Chords"

This pack of sounds contains sounds by the following user:
 - blakengouda ( https://freesound.org/people/blakengouda/ )

You can find this pack online at: https://freesound.org/people/blakengouda/packs/29677/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 528026__blakengouda__f-piano-chord.wav
    * url: https://freesound.org/s/528026/
    * license: Creative Commons 0
  * 528025__blakengouda__fm-piano-chord.wav
    * url: https://freesound.org/s/528025/
    * license: Creative Commons 0
  * 528024__blakengouda__e-piano-chord.wav
    * url: https://freesound.org/s/528024/
    * license: Creative Commons 0
  * 528023__blakengouda__em-piano-chord.wav
    * url: https://freesound.org/s/528023/
    * license: Creative Commons 0
  * 528022__blakengouda__f-piano-chord.wav
    * url: https://freesound.org/s/528022/
    * license: Creative Commons 0
  * 528021__blakengouda__f-m-piano-chord.wav
    * url: https://freesound.org/s/528021/
    * license: Creative Commons 0
  * 528020__blakengouda__d-piano-chord.wav
    * url: https://freesound.org/s/528020/
    * license: Creative Commons 0
  * 528019__blakengouda__d-m-piano-chord.wav
    * url: https://freesound.org/s/528019/
    * license: Creative Commons 0
  * 528018__blakengouda__d-piano-chord.wav
    * url: https://freesound.org/s/528018/
    * license: Creative Commons 0
  * 528017__blakengouda__dm-piano-chord.wav
    * url: https://freesound.org/s/528017/
    * license: Creative Commons 0
  * 528016__blakengouda__g-m-piano-chord.wav
    * url: https://freesound.org/s/528016/
    * license: Creative Commons 0
  * 528015__blakengouda__g-piano-chord.wav
    * url: https://freesound.org/s/528015/
    * license: Creative Commons 0
  * 528014__blakengouda__gm-piano-chord.wav
    * url: https://freesound.org/s/528014/
    * license: Creative Commons 0
  * 528013__blakengouda__g-piano-chord.wav
    * url: https://freesound.org/s/528013/
    * license: Creative Commons 0
  * 528012__blakengouda__c-piano-chord.wav
    * url: https://freesound.org/s/528012/
    * license: Creative Commons 0
  * 528011__blakengouda__cm-piano-chord.wav
    * url: https://freesound.org/s/528011/
    * license: Creative Commons 0
  * 528010__blakengouda__b-piano-chord.wav
    * url: https://freesound.org/s/528010/
    * license: Creative Commons 0
  * 528009__blakengouda__bm-piano-chord.wav
    * url: https://freesound.org/s/528009/
    * license: Creative Commons 0
  * 528008__blakengouda__c-piano-chord.wav
    * url: https://freesound.org/s/528008/
    * license: Creative Commons 0
  * 528007__blakengouda__c-m-piano-chord.wav
    * url: https://freesound.org/s/528007/
    * license: Creative Commons 0
  * 528006__blakengouda__a-piano-chord.wav
    * url: https://freesound.org/s/528006/
    * license: Creative Commons 0
  * 528005__blakengouda__a-m-piano-chord.wav
    * url: https://freesound.org/s/528005/
    * license: Creative Commons 0
  * 528004__blakengouda__a-piano-chord.wav
    * url: https://freesound.org/s/528004/
    * license: Creative Commons 0
  * 528003__blakengouda__am-piano-chord.wav
    * url: https://freesound.org/s/528003/
    * license: Creative Commons 0


